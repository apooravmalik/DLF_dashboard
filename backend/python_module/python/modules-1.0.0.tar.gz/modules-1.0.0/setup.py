from distutils.core import setup

setup(


name = 'modules',
version = '1.0.0',
py_modules = ['modules'],
author = 'rakesh',
author_email = 'rakeshnitcalicut@gmail.com',
url = 'www.facebook.com/rakeshbubli',
description = 'Simple test on modules',
 





)
