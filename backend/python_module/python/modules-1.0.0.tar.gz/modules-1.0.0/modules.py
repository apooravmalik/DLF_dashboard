def show(a):
	print(a)
def size(a):
	print(len(a))	
